import React from 'react'

const FirstApp = () => {
  return (
    <div>
        <h1>Hello Miracle I am back </h1>
    </div>
  )
}

export default FirstApp
