import React, { useState } from 'react';
import { Routes, Route, Navigate,    BrowserRouter } from "react-router-dom";
import Layout2 from './Layouts/Layout2';

import Layout from './Layouts/Layout';
import Crads from './components/Crads';


const App = () => {
  const[user,setUser]=useState(true);
  return <Layout/>


 
};

export default App;
