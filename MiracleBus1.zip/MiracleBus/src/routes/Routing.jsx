import React from 'react'
import { Routes, Route, Navigate,    BrowserRouter } from "react-router-dom";
import Login from '../components/Login';
import Registration from '../components/Registration';
import Crads from '../components/Crads';
import { useAuthContext } from '../context/AuthContext';



const Routing = () => {
  const { authUser } = useAuthContext();
  return (
    <>

    <Routes>
    
        <Route path='/' element={authUser ? <Crads/> : <Navigate to={"/Login"} />} />
				<Route path='/Login' element={authUser ? <Navigate to='/' /> : <Login />} />
				<Route path='/Registration' element={authUser ? <Navigate to='/' /> : <Registration />} />
  

    </Routes>
  
    </>

    

  )
}

export default Routing
